# Fullwidth Post Title
`divi/fullwidth-post-title`

- Category: `fullwidth-module`
- Divi version: 5.14.0
- Schema version: `9497acfd86bde70cd3809f1f6ccd1ae3cae14651`

## Element Map

| Element | Type | Decoration Paths |
|---------|------|-----------------|
| `className` | `string` | — |
| `featuredImage` | `object` | `featuredImage.settings.decoration.sizing` |
| `lock` | `object` | — |
| `meta` | `object` | `meta.settings.decoration.font` |
| `metadata` | `object` | — |
| `module` | `object` | `module.settings.decoration.animation`, `module.settings.decoration.attributes`, `module.settings.decoration.background`, `module.settings.decoration.border`, `module.settings.decoration.boxShadow`, `module.settings.decoration.conditions`, `module.settings.decoration.disabledOn`, `module.settings.decoration.filters` *(+11 more)* |
| `style` | `object` | — |
| `textWrapper` | `object` | `textWrapper.settings.decoration.background` |
| `title` | `object` | `title.settings.decoration.font`, `title.settings.decoration.font.headingLevel` |

### `featuredImage` decoration paths

- `featuredImage.settings.decoration.sizing`

### `meta` decoration paths

- `meta.settings.decoration.font`

### `module` decoration paths

- `module.settings.decoration.animation`
- `module.settings.decoration.attributes`
- `module.settings.decoration.background`
- `module.settings.decoration.border`
- `module.settings.decoration.boxShadow`
- `module.settings.decoration.conditions`
- `module.settings.decoration.disabledOn`
- `module.settings.decoration.filters`
- `module.settings.decoration.interactions`
- `module.settings.decoration.order`
- `module.settings.decoration.overflow`
- `module.settings.decoration.position`
- `module.settings.decoration.scroll`
- `module.settings.decoration.sizing`
- `module.settings.decoration.spacing`
- `module.settings.decoration.sticky`
- `module.settings.decoration.transform`
- `module.settings.decoration.transition`
- `module.settings.decoration.zIndex`

### `textWrapper` decoration paths

- `textWrapper.settings.decoration.background`

### `title` decoration paths

- `title.settings.decoration.font`
- `title.settings.decoration.font.headingLevel`

## CSS Selectors

| Element | Selector |
|---------|----------|
| `module` | `{{selector}}` |
| `title` | `{{selector}} .et_pb_title_container h1.entry-title,{{selector}} .et_pb_title_container h2.entry-title,{{selector}} .et_p...` |
| `meta` | `{{selector}} .et_pb_title_container .et_pb_title_meta_container, {{selector}} .et_pb_title_container .et_pb_title_meta_c...` |
| `textWrapper` | `{{selector}} .et_pb_title_container` |
| `featuredImage` | `{{selector}} .et_pb_title_featured_container img` |
